package br.edu.ufpi.ccn036.budgetapp;

public class Main {
	public static void main(String[] args) {
		new App().init(args);
	}
}
